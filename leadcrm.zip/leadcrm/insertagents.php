

   <?php
  	if (isset($_POST['submit'])) {
require_once("dbconfig.php");
$name = trim($_POST['agentname']);
   $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
   
    $logo = $_FILES["passport"]["name"];
    $datetime = date('Y-m-d H:i:s');
   
 
 $stmt = $conn->prepare("INSERT INTO agents(name,phone,email,passport,date_t)VALUES(?,?,?,?,?)");
$stmt->execute([$name,$phone,$email,$logo,$datetime]);
$stmt = null;

	$logo=$_FILES["passport"]["name"];
	

	move_uploaded_file($_FILES["passport"]["tmp_name"],"passports/".$_FILES["passport"]["name"]);	

$success = true; 
if ($success) {
    echo "<script>
            alert('Save Successful');
            window.location.href = 'add_agent.php';
          </script>";
    exit(); 
} else {
    
    echo "<script>alert('Save Failed');</script>";
}


	
}


$conn->close();

?>
