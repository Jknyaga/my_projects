require 'PHPExcel.php';

// Initialize PHPExcel object
$excel = new PHPExcel();
$excel->getActiveSheet()->setTitle('Lead Report');

// Set headings
$excel->getActiveSheet()->setCellValue('A1', 'Lead Name');
$excel->getActiveSheet()->setCellValue('B1', 'Email');
$excel->getActiveSheet()->setCellValue('C1', 'Phone');
$excel->getActiveSheet()->setCellValue('D1', 'Status');

// Fetch data and write to the excel file
$leads = $conn->query("SELECT * FROM leads");
$rowNumber = 2;
while ($row = $leads->fetch_assoc()) {
    $excel->getActiveSheet()->setCellValue('A' . $rowNumber, $row['name']);
    $excel->getActiveSheet()->setCellValue('B' . $rowNumber, $row['email']);
    $excel->getActiveSheet()->setCellValue('C' . $rowNumber, $row['phone']);
    $excel->getActiveSheet()->setCellValue('D' . $rowNumber, $row['status']);
    $rowNumber++;
}

// Save Excel file
$writer = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
$writer->save('Lead_Report.xlsx');
