<?php
include 'db.php';

if (isset($_POST['update'])) {
    // Collect the form data
    $id = $_POST['agent_id'];  // Make sure 'agent_id' is sent in the form
    $agent = $_POST['agentname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $passport = $_FILES["passport"]["name"];

    // Update the agent information in the database
    $sql = "UPDATE agents SET name = ?, phone = ?, email = ?, passport = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssi', $agent, $phone, $email, $passport, $id);

    if ($stmt->execute()) {
        	$passport=$_FILES["passport"]["name"];
	

	move_uploaded_file($_FILES["passport"]["tmp_name"],"passports/".$_FILES["passport"]["name"]);	
        // If the update is successful, redirect back to the agents page
        echo "<script>alert('Agent updated successfully!');window.location.href='agents.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}
?>
