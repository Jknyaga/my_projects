
        // Function to search the table
        function searchTable() {
            const input = document.getElementById("searchInput");
            const filter = input.value.toLowerCase();
            const table = document.getElementById("myTable");
            const rows = table.getElementsByTagName("tr");

            // Loop through all table rows, skipping the header (index 0)
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const cells = row.getElementsByTagName("td");
                let match = false;

                // Check each cell in the row
                for (let j = 0; j < cells.length; j++) {
                    const cell = cells[j];
                    if (cell.innerText.toLowerCase().includes(filter)) {
                        match = true; // Found a match
                        break;
                    }
                }

                // Show or hide the row based on match result
                row.style.display = match ? "" : "none";
            }
        }

        // Add event listener to the search input
        document.getElementById("searchInput").addEventListener("keyup", searchTable);
    