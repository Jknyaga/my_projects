<?php
// Database connection
$servername = "localhost";
$username = "buysgzjw_isure";
$password = "operamini22";
$dbname = "buysgzjw_lead_management_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['import'])) {
    // Check if a file is uploaded
    if (is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
        $file = fopen($_FILES['csv_file']['tmp_name'], 'r');

        // Skip the first line if your CSV has column headers
        fgetcsv($file);

        // Prepare the SQL query to insert contacts
        $stmt = $conn->prepare("INSERT INTO contacts (firstname, email, phone) VALUES (?, ?, ?)");

        // Check if prepare() failed
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }

        // Bind parameters
        $stmt->bind_param("sss", $name, $email, $phone);

        // Loop through each row in the CSV file
        while (($row = fgetcsv($file)) !== FALSE) {
            // Assuming your CSV columns are Name, Email, Phone in that order
            $name = $row[0];
            $email = $row[1];
            $phone = $row[2];

            // Execute the prepared statement for each row
            if (!$stmt->execute()) {
                echo "Error inserting row: " . $stmt->error . "<br>";
            }
        }

        fclose($file);
        echo "Contacts imported successfully!";
    } else {
        echo "Please upload a CSV file.";
    }
}

$conn->close();
?>
