<?php
include 'db.php';

// Fetch the lead count based on status
$statusReport = $conn->query("
    SELECT 
        status, COUNT(*) as count 
    FROM leads 
    GROUP BY status
");

// Fetch lead count by campaign
$campaignReport = $conn->query("
    SELECT 
        c.campaign_name, COUNT(l.id) as count
    FROM leads l
    LEFT JOIN campaigns c ON l.campaign_id = c.id
    GROUP BY l.campaign_id
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lead Reports</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h1>Lead Conversion Report</h1>
    
    <h2>Lead Status Report</h2>
    <canvas id="statusChart"></canvas>

    <h2>Campaign-wise Lead Count</h2>
    <canvas id="campaignChart"></canvas>

    <script>
        // Data for Status Chart
        const statusData = {
            labels: [
                <?php while($row = $statusReport->fetch_assoc()) echo "'{$row['status']}',"; ?>
            ],
            datasets: [{
                label: 'Lead Count',
                data: [
                    <?php while($row = $statusReport->fetch_assoc()) echo "{$row['count']},"; ?>
                ],
                backgroundColor: ['#ff6384', '#36a2eb', '#cc65fe'],
            }]
        };

        // Data for Campaign Chart
        const campaignData = {
            labels: [
                <?php while($row = $campaignReport->fetch_assoc()) echo "'{$row['campaign_name']}',"; ?>
            ],
            datasets: [{
                label: 'Lead Count',
                data: [
                    <?php while($row = $campaignReport->fetch_assoc()) echo "{$row['count']},"; ?>
                ],
                backgroundColor: ['#ffce56', '#ff6384', '#36a2eb'],
            }]
        };

        // Create Charts
        new Chart(document.getElementById('statusChart'), {
            type: 'pie',
            data: statusData
        });

        new Chart(document.getElementById('campaignChart'), {
            type: 'bar',
            data: campaignData
        });
    </script>
</body>
</html>
