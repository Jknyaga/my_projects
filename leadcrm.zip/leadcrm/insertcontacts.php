

   <?php
  	if (isset($_POST['submit'])) {
  	    
require_once("dbconfig.php");
$fname = trim($_POST['firstname']);
$lname = trim($_POST['lastname']);
   $location = trim($_POST['location']);
    $phone= trim($_POST['phone']);
   $company = trim($_POST['company']);
   $email = trim($_POST['email']);
    $narration= trim($_POST['narration']);
   
    
    $datetime = date('Y-m-d H:i:s');
   
 
 $stmt = $conn->prepare("INSERT INTO contacts(firstname,lastname,location,email,phone,company,narration,date_t)VALUES(?,?,?,?,?,?,?,?)");
$stmt->execute([$fname,$lname,$location,$email,$phone,$company,$narration,$datetime]);
$stmt = null;
	

$success = true; 
if ($success) {
    echo "<script>
            alert('Save Successful');
            window.location.href = 'add_contact.php';
          </script>";
    exit(); 
} else {
    
    echo "<script>alert('Save Failed');</script>";
}


	
}


$conn->close();

?>
