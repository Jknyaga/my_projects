<?php
$host = "localhost"; // Your host name 
$dbname = "buysgzjw_lead_management_db";       // Your database name
$username = "buysgzjw_isure";            // Your login userid 
$password = "operamini22";  
 
try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    //echo "Connected to $dbname at $host successfully.";
} catch (PDOException $pe) {
    die("Could not connect to the database $dbname :" . $pe->getMessage());
}
?>