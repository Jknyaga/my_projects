<?php
session_start();
include 'dbconfig.php';

if (isset($_POST['submit'])) {
    $fullnames = $_POST['fullnames'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $_SESSION['message'] = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

       $stmt = $conn->prepare("INSERT INTO users(email,password,fullnames)VALUES(?,?,?)");
$stmt->execute([$email,$hashed_password,$fullnames]);
$stmt = null;
	

$success = true; 
if ($success) {
    echo "<script>
            alert('Save Successful');
            window.location.href = 'add_user.php';
          </script>";
    exit(); 
} else {
    
    echo "<script>alert('Save Failed');</script>";
}


	
}
}

$conn->close();
?>