

   <?php
  	if (isset($_POST['submit'])) {
require_once("dbconfig.php");
$name = trim($_POST['propertyname']);
   $location = trim($_POST['location']);
    $price= trim($_POST['price']);
   $type = trim($_POST['propertytype']);
   $bedrooms = trim($_POST['bedrooms']);
    $price= trim($_POST['price']);
   
    
    $datetime = date('Y-m-d H:i:s');
   
 
 $stmt = $conn->prepare("INSERT INTO properties(property_name,property_type,location,price,bedrooms,date_t)VALUES(?,?,?,?,?,?)");
$stmt->execute([$name,$type,$location,$price,$bedrooms,$datetime]);
$stmt = null;
	

$success = true; 
if ($success) {
    echo "<script>
            alert('Save Successful');
            window.location.href = 'add_property.php';
          </script>";
    exit(); 
} else {
    
    echo "<script>alert('Save Failed');</script>";
}


	
}


$conn->close();

?>
