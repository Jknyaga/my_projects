

   <?php
  	if (isset($_POST['submit'])) {
  	    
require_once("dbconfig.php");
$name = trim($_POST['name']);
$narration= trim($_POST['description']);
   
    
    $datetime = date('Y-m-d H:i:s');
   
 
 $stmt = $conn->prepare("INSERT INTO campaigns(campaign_name,description,date_t)VALUES(?,?,?)");
$stmt->execute([$name,$narration,$datetime]);
$stmt = null;
	

$success = true; 
if ($success) {
    echo "<script>
            alert('Save Successful');
            window.location.href = 'add_campaign.php';
          </script>";
    exit(); 
} else {
    
    echo "<script>alert('Save Failed');</script>";
}


	
}


$conn->close();

?>
