<?php
include"header.php";
?>
<style>
        /* Hide the dropdown by default */
        .dropdown-hidden {
            display: none;
        }
    </style>
       <br>
            <!-- CTA -->
            <button
              class="flex  px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-green-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-green-700 focus:outline-none focus:shadow-outline-green" style="width:100%;"
            >
             <h5  ><a href="campaigns.php">View Campaigns</a></h5>
            </button>

            <!-- General elements -->
           <main class="h-full pb-16 overflow-y-auto">
          <div class="container px-6 mx-auto grid">
          <div class="container mx-auto">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        
       <h5 class="text-1xl font-bold mb-5">Add a Campaign
       <label style="padding-left:50%;"></label>
     
</h5>
      
      <form action="insertcampaign.php" method="POST" enctype="multipart/form-data">
         
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <!-- First Name -->
          <div>
            <label for="first_name" class="block text-sm font-medium text-gray-700">Campaign Name</label>
            <input type="text" id="name" name="name" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

          <!-- Last Name -->
           <div>
            <label for="first_name" class="block text-sm font-medium text-gray-700">Description</label>
            <input type="text" id="description" name="description" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
         

        </div>

        <!-- Submit Button -->
        <div class="mt-6">
          <input type="submit" id="submit" name="submit" class="px-4 py-2 bg-blue-600 text-white font-semibold rounded-md shadow-sm hover:bg-blue-700">
        </div>
      </form>
    </div>
  </div>

          
          </div>
        </main>
      </div>
    </div>
  
  </body>
</html>
