<?php
include 'db.php';

if (isset($_POST['update'])) {
    // Collect the form data
    $id = $_POST['agent_id'];  // Make sure 'agent_id' is sent in the form
    $fname = $_POST['firstname'];
    $lname= $_POST['lastname'];
    $location = $_POST['location'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $company= $_POST['company'];
    echo $email;
    

    // Update the agent information in the database
    $sql = "UPDATE contacts SET firstname = ?, lastname = ?, phone = ?, location = ? , email = ?, company = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssdsisi', $fname, $lname, $phone, $location, $email, $company, $id);

    if ($stmt->execute()) {
        		
        // If the update is successful, redirect back to the agents page
        echo "<script>alert('Contact updated successfully!');window.location.href='contacts.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}
?>
