<?php
// Database connection
$host = 'localhost';
$db = 'buysgzjw_lead_management_db';
$user = 'buysgzjw_isure';
$pass = 'operamini22';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// Fetch agents
$agentsResult = $conn->query("SELECT * FROM agents");
$agents = [];
while ($row = $agentsResult->fetch_assoc()) {
    $agents[] = $row;
}

// Handle form submission for assigning leads
// Handle form submission for assigning leads
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $assignedAgentId = $_POST['agent_id'];
    $leadIds = $_POST['lead_ids'] ?? [];

    if (!empty($leadIds)) {
        // Prepare the SQL statement for insertion
        $stmt = $conn->prepare("INSERT INTO assignleads (lead_id, assigned_agent_id) VALUES (?, ?)");

        // Loop through each selected lead and execute the prepared statement
        foreach ($leadIds as $leadId) {
            $stmt->bind_param("ii", $leadId, $assignedAgentId);
            $stmt->execute();
        }

        $stmt->close();
        echo "<script>
            alert('Assign Successful');
            window.location.href = 'assign_leads.php';
          </script>";
    exit(); 
    } else {
         echo "<script>
            alert('Assign Not Successful');
            window.location.href = 'assign_leads.php';
          </script>";
    exit(); 
    }
}

$conn->close();
?>

<?php
include "header.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);
include "dbconfig.php";

$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Create a new PDO instance
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Prepare and execute a statement to retrieve data
$stmt = $pdo->prepare('SELECT * FROM leads ');
$stmt->execute();
$companies = $stmt->fetchAll();
?>
<style>
        /* Custom styles for alternating row colors */
        .table-row-even {
            background-color: #f9fafb; /* Light gray */
        }
        .table-row-odd {
            background-color: #ffffff; /* White */
        }
    </style>
<main class="h-full pb-16 overflow-y-auto">
    <div class="container grid px-6 mx-auto">
        <a class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-purple-100 bg-green-600 rounded-lg shadow-md" href="add_lead.php">
            <div class="flex items-center">
                <span>Add a Lead</span>
            </div>
        </a>

        <h5 class="mb-4 text-lg font-semibold text-gray-600">Assigning Agent to Leads...</h5>
        <form method="POST">
            
            <select name="agent_id" id="agent_id" required class="w-half border border-gray-300 rounded-md p-1">
                <option value="">-- Select an Agent --</option>
                <?php foreach ($agents as $agent): ?>
                    <option value="<?php echo $agent['id']; ?>"><?php echo htmlspecialchars($agent['name']); ?></option>
                <?php endforeach; ?>
            </select>
            
    

            <label for="agent" style="margin-left:40%;"></label>
            <input type="text" placeholder="search" id="searchInput" class="w-half border border-gray-300 rounded-md p-1">
           
            <table class="w-full" id="myTable">
                <thead >
                    <tr   class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800"
                   >
                        <th class="px-4 py-3">Assign</th>
                        <th class="px-4 py-3">First Name</th>
                        <th class="px-4 py-3">Last Name</th>
                        <th class="px-4 py-3">Phone</th>
                        <th class="px-4 py-3">Email</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800">
                    <?php if (count($companies) > 0): ?>
                        <?php foreach ($companies as $company): ?>
                            <tr class="text-gray-700">
                                <td class="px-4 py-3 text-sm">
                                    <input type="checkbox" name="lead_ids[]" value="<?php echo $company['id']; ?>" id="lead-<?php echo $company['id']; ?>">
                                </td>
                                <td class="px-4 py-3 text-sm"><?php echo htmlspecialchars($company['firstname']); ?></td>
                                <td class="px-4 py-3 text-sm"><?php echo htmlspecialchars($company['lastname']); ?></td>
                                <td class="px-4 py-3 text-xs"><?php echo htmlspecialchars($company['phone']); ?></td>
                                <td class="px-4 py-3 text-xs"><?php echo htmlspecialchars($company['email']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="py-2 px-4 border text-center">No data found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <br>
            <button type="submit" class="px-4 py-2 bg-green-600 text-white font-semibold rounded-md shadow-sm hover:bg-green-700">Assign Leads</button>
        </form>
    </div>
</main>

<script>
    // Function to search the table
    function searchTable() {
        const input = document.getElementById("searchInput");
        const filter = input.value.toLowerCase();
        const table = document.getElementById("myTable");
        const rows = table.getElementsByTagName("tr");

        for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            const cells = row.getElementsByTagName("td");
            let match = false;

            for (let j = 0; j < cells.length; j++) {
                const cell = cells[j];
                if (cell.innerText.toLowerCase().includes(filter)) {
                    match = true;
                    break;
                }
            }

            row.style.display = match ? "" : "none";
        }
    }

    document.getElementById("searchInput").addEventListener("keyup", searchTable);
</script>

</body>
</html>
