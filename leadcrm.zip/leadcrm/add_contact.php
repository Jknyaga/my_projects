<?php
include"header.php";
?>
<style>
        /* Hide the dropdown by default */
        .dropdown-hidden {
            display: none;
        }
    </style>
       <br>
            <!-- CTA -->
            <button
              class="flex  px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-green-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-green-700 focus:outline-none focus:shadow-outline-purple" style="width:100%;"
            >
             <h5  ><a href="contacts.php">View Contacts</a></h5>
            </button>

            <!-- General elements -->
           <main class="h-full pb-16 overflow-y-auto">
          <div class="container px-6 mx-auto grid">
          <div class="container mx-auto">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        
       <h5 class="text-1xl font-bold mb-5">Add a Contact
       <label style="padding-left:50%;"></label>
       <div class="relative inline-block text-left">
    <div>
        <button id="menu-button" type="button" class="inline-flex justify-center w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-green text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            Import Contacts
            <svg class="-mr-1 ml-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06 0L10 10.293l3.71-3.07a.75.75 0 111.04 1.08l-4.25 3.5a.75.75 0 01-.9 0l-4.25-3.5a.75.75 0 010-1.08z" clip-rule="evenodd" />
            </svg>
        </button>
    </div>

    <div id="dropdown-menu" class="absolute right-0 z-10 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 dropdown-hidden">
        <div class="py-1" role="none">
            <a href="import.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">CSV File</a>
            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Option 2</a>
            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Option 3</a>
        </div>
    </div>
</div>
</h5>
      
      <form action="insertcontacts.php" method="POST" enctype="multipart/form-data">
         
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <!-- First Name -->
          <div>
            <label for="first_name" class="block text-sm font-medium text-gray-700">First Name</label>
            <input type="text" id="firstname" name="firstname" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

          <!-- Last Name -->
           <div>
            <label for="first_name" class="block text-sm font-medium text-gray-700">First Name</label>
            <input type="text" id="lastname" name="lastname" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
          <!-- Email -->
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Phone</label>
            <input type="text" id="phone" name="phone" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
          
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
            <input type="text" id="email" name="email" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
          <div>
            <label for="last_name" class="block text-sm font-medium text-gray-700">Location</label>
            <input type="text" id="location" name="location" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
           <div>  
            <label for="email" class="block text-sm font-medium text-gray-700">Company Name</label>
            <input type="text" id="company" name="company" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
          <div>  
            <label for="email" class="block text-sm font-medium text-gray-700">Narration</label>
            <input type="text" id="narration" name="narration" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
         
         
          

        </div>

        <!-- Submit Button -->
        <div class="mt-6">
          <input type="submit" id="submit" name="submit" class="px-4 py-2 bg-blue-600 text-white font-semibold rounded-md shadow-sm hover:bg-blue-700">
        </div>
      </form>
    </div>
  </div>

          
          </div>
        </main>
      </div>
    </div>
   <script>
    document.getElementById('menu-button').addEventListener('click', function() {
        const dropdown = document.getElementById('dropdown-menu');
        dropdown.classList.toggle('dropdown-hidden');
    });

    // Close dropdown if clicked outside
    window.addEventListener('click', function(event) {
        const dropdown = document.getElementById('dropdown-menu');
        if (!event.target.closest('.relative')) {
            dropdown.classList.add('dropdown-hidden');
        }
    });
</script>
  </body>
</html>
