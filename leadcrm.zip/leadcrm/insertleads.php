

   <?php
  	if (isset($_POST['submit'])) {
  	    
require_once("dbconfig.php");
$fname = trim($_POST['firstname']);
$lname = trim($_POST['lastname']);
   $occupation = trim($_POST['occupation']);
    $phone= trim($_POST['phone']);
   $status = trim($_POST['status']);
   $email = trim($_POST['email']);
    $campaign= trim($_POST['campaign_id']);
     $agent= trim($_POST['agent_id']);
   
    
    $datetime = date('Y-m-d H:i:s');
   
 
 $stmt = $conn->prepare("INSERT INTO leads(firstname,lastname,occupation,email,phone,campaign_id,assigned_agent_id,created_at,status)VALUES(?,?,?,?,?,?,?,?,?)");
$stmt->execute([$fname,$lname,$occupation,$email,$phone,$campaign,$agent,$datetime,$status]);
$stmt = null;
	

$success = true; 
if ($success) {
    echo "<script>
            alert('Save Successful');
            window.location.href = 'add_lead.php';
          </script>";
    exit(); 
} else {
    
    echo "<script>alert('Save Failed');</script>";
}


	
}


$conn->close();

?>
