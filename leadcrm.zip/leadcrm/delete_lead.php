<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM leads WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Lead deleted successfully!";
    header('Location: index.php');
} else {
    echo "Error deleting lead: " . $conn->error;
}
?>
