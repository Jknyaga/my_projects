<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];

    $sql = "INSERT INTO agents (name, phone) VALUES ('$name', '$phone')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New agent added successfully!";
        header('Location: agents.php');  // Redirect to a list of agents
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Agent</title>
</head>
<body>
    <h1>Add New Agent</h1>
    <form method="post">
        <label>Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Phone:</label><br>
        <input type="text" name="phone" required><br><br>

        <input type="submit" value="Add Agent">
    </form>
</body>
</html>
