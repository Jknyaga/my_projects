<?php
session_start();
include 'dbconfig.php';

if (isset($_POST['submit'])) {
    $username = $_POST['email'];
    $password = $_POST['password'];

    // Initialize login attempts
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 0;
    }

    // Check for too many attempts
    if ($_SESSION['login_attempts'] >= 3) {
        $_SESSION['message'] = "Too many login attempts. Please try again later.";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['fullnames'];
            $_SESSION['login_attempts'] = 0; // Reset attempts on success
            header("Location: admin.php");
            exit;
        } else {
            $_SESSION['login_attempts']++;
            $_SESSION['message'] = "Invalid username or password.";
        }
    }
}
?>
