<?php
include 'db.php';

$id = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $status = $_POST['status'];

    $sql = "UPDATE leads SET name='$name', email='$email', phone='$phone', status='$status' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Lead updated successfully!";
        header('Location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$sql = "SELECT * FROM leads WHERE id=$id";
$result = $conn->query($sql);
$lead = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Lead</title>
</head>
<body>
    <h1>Edit Lead</h1>
    <form method="post">
        <label>Name:</label><br>
        <input type="text" name="name" value="<?php echo $lead['name']; ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo $lead['email']; ?>" required><br><br>

        <label>Phone:</label><br>
        <input type="text" name="phone" value="<?php echo $lead['phone']; ?>"><br><br>

        <label>Status:</label><br>
        <select name="status">
            <option value="pending" <?php if ($lead['status'] == 'pending') echo 'selected'; ?>>Pending</option>
            <option value="contacted" <?php if ($lead['status'] == 'contacted') echo 'selected'; ?>>Contacted</option>
            <option value="converted" <?php if ($lead['status'] == 'converted') echo 'selected'; ?>>Converted</option>
        </select><br><br>

        <input type="submit" value="Update Lead">
    </form>
</body>
</html>
