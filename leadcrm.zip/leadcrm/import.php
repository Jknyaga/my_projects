

<?php
include"header.php";
?>
<style>
        /* Hide the dropdown by default */
        .dropdown-hidden {
            display: none;
        }
    </style>
       <br>
            <!-- CTA -->
            <button
              class="flex  px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple" style="width:100%;"
            >
             <h5  ><a href="contacts.php">View Contacts</a></h5>
            </button>

            <!-- General elements -->
           <main class="h-full pb-16 overflow-y-auto">
          <div class="container px-6 mx-auto grid">
          <div class="container mx-auto">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        
      
      
</h5>
       <h5  ><a href="contacts.php">Please Upload a CSV File....</a></h5>
       <br>
  
    <form action="import_contacts.php" method="post" enctype="multipart/form-data">
        <input type="file" name="csv_file" accept=".csv" required>
        <br><br>
        <button type="submit" name="import" class="px-4 py-2 bg-blue-600 text-white font-semibold rounded-md shadow-sm hover:bg-blue-700">Import </button>
    </form>    
      
      
      
    </div>
  </div>

          
          </div>
        </main>
      </div>
    </div>
  
  </body>
</html>
