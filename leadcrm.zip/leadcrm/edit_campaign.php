<?php
include"header.php";
include 'db.php';

// Get the campaign ID from the query string
$id = $_GET['id'];

// Fetch the current campaign data
$campaign = $conn->query("SELECT * FROM campaigns WHERE id = $id")->fetch_assoc();
?>

            <br>
            <!-- CTA -->
            <button
              class="flex  px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple" style="width:100%;"
            >
             <h5  ><a href="contacts.php">View Campaigns</a></h5>
            </button>

            <!-- General elements -->
           <main class="h-full pb-16 overflow-y-auto">
          <div class="container px-6 mx-auto grid">
          <div class="container mx-auto">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        
      <h5 class="text-1xl font-bold mb-5">Updating Campaign Details.... </h5>
      
      <form action="campaignedit.php" method="POST" enctype="multipart/form-data">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
           <input type="hidden" name="agent_id" value="<?php echo htmlspecialchars($campaign['id']); ?>" />
          <!-- First Name -->
         

         <div>
            <label for="first_name" class="block text-sm font-medium text-gray-700">Campaign Name</label>
            <input type="text" id="campaign_name" name="campaign_name" value="<?php echo htmlspecialchars($campaign['campaign_name']); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

          <!-- Last Name -->
          <div>
            <label for="last_name" class="block text-sm font-medium text-gray-700">Description</label>
            <input type="text" id="description" name="description"  value="<?php echo htmlspecialchars($campaign['description']); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

          <!-- Email -->
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Date Created</label>
            <input type="datetime" id="date_t" name="date_t" value="<?php echo htmlspecialchars($campaign['created_on']); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Created By</label>
            <input type="text" id="ctreated_by" name="created_by" value="<?php echo htmlspecialchars($campaign['created_by']); ?>" required class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>
        

          

        </div>


        <!-- Submit Button -->
        <div class="mt-6">
          <input type="submit" id="update" name="update" class="px-4 py-2 bg-green-600 text-white font-semibold rounded-md shadow-sm hover:bg-green-700">
        </div>
      </form>
    </div>
  </div>

          
          </div>
        </main>
      </div>
    </div>
  </body>
</html>
