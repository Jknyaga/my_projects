<?php
include 'db.php';

if (isset($_POST['update'])) {
    // Collect the form data
    $id = $_POST['agent_id'];  // Make sure 'agent_id' is sent in the form
    $name = $_POST['propertyname'];
    $type = $_POST['propertytype'];
    $location = $_POST['location'];
    $price = $_POST['price'];
    $bedrooms = $_POST['bedrooms'];
    $status= $_POST['property_status'];
    
    

    // Update the agent information in the database
    $sql = "UPDATE properties SET property_name = ?, property_type = ?, price = ?, location = ? , bedrooms = ?, property_status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssdsisi', $name, $type, $price, $location, $bedrooms, $status, $id);

    if ($stmt->execute()) {
        		
        // If the update is successful, redirect back to the agents page
        echo "<script>alert('Property updated successfully!');window.location.href='properties.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}
?>
