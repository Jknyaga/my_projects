<?php
include"header.php";
?>
            <br>
            <!-- CTA -->
            <button
              class="flex  px-4 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple" style="width:100%;"
            >
             <h5  ><a href="agents.php">View Agents</a></h5>
            </button>

            <!-- General elements -->
           <main class="h-full pb-16 overflow-y-auto">
          <div class="container px-6 mx-auto grid">
          <div class="container mx-auto">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        
      <h5 class="text-1xl font-bold mb-5">Add Agent </h5>
      
      <form action="insertagents.php" method="POST" enctype="multipart/form-data">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <!-- First Name -->
          <div>
            <label for="first_name" class="block text-sm font-medium text-gray-700">Agent Name</label>
            <input type="text" id="agentname" name="agentname" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

          <!-- Last Name -->
          <div>
            <label for="last_name" class="block text-sm font-medium text-gray-700">Phone No</label>
            <input type="tel" id="phone" name="phone" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

          <!-- Email -->
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
            <input type="email" id="email" name="email" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

         
        

         
         
         
          <div>
            <label for="confirm_password" class="block text-sm font-medium text-gray-700">Passport Photo</label>
           <input type="file" id="passport" name="passport" class="mt-1 block w-full border border-gray-300 rounded-md p-2">
          </div>

        </div>

        <!-- Submit Button -->
        <div class="mt-6">
          <input type="submit" id="submit" name="submit" class="px-4 py-2 bg-blue-600 text-white font-semibold rounded-md shadow-sm hover:bg-blue-700">
        </div>
      </form>
    </div>
  </div>

          
          </div>
        </main>
      </div>
    </div>
  </body>
</html>
