<?php
include 'db.php';

if (isset($_POST['update'])) {
    // Collect the form data
    $id = $_POST['agent_id'];  // Make sure 'agent_id' is sent in the form
    $fname = $_POST['campaign_name'];
    $description= $_POST['description'];
    $owner = $_POST['created_by'];
    $date = $_POST['created_on'];
    

    // Update the agent information in the database
    $sql = "UPDATE campaigns SET campaign_name = ?, description = ?, created_by = ?, created_on = ?  WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssdi', $fname, $description, $owner, $date, $id);

    if ($stmt->execute()) {
        		
        // If the update is successful, redirect back to the agents page
        echo "<script>alert('Campaign updated successfully!');window.location.href='campaigns.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}
?>
